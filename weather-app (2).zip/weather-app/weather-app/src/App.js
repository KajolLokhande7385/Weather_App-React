import logo from './logo.svg';
import './App.css';
import WeatherChart from './WeatherChart';
import SearchCity from './SearchCity';

const onSearch = async (city) => {
  console.log('city:', city);
  const API_KEY= `e2e687cd545f7a49f0606efb1ac059b1`
  //Use correct API mentioned in given Doc
  const url=`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
  const response =await fetch(url);
  const data=await response.json()
  console.log('data:', data)
}

function App() {
  return (
    <div className="App">
      <SearchCity onSearch={onSearch}/>
      {/* Pass Data to WeatherChart by using props */}
      <WeatherChart/>
    </div>
  );
}

export default App;
