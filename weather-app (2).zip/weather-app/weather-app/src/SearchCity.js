import { Input, Space } from 'antd';
import { EnvironmentOutlined } from '@ant-design/icons';

const { Search } = Input;

const SearchCity = (props) => (
    <Space direction="vertical">
    <Search placeholder="input city" onSearch={props.onSearch} style={{ width: 300 }}  prefix={<EnvironmentOutlined />} />
  </Space>
);
export default SearchCity;